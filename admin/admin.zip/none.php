<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Selamat datang - <?php echo $_SESSION['username']; ?></h1>
</div>

<section id="none">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header">
                        Visi
                    </div>
                    <div class="card-body">
                        Isi Visi Disini
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header">
                        Misi
                    </div>
                    <div class="card-body">
                        Isi Misi Disini
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-header">
                        Tujuan
                    </div>
                    <div class="card-body">
                        Isi Tujuan Disini
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>